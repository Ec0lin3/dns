﻿##DONT FORGET TO CHANGE THE IP RANGE
##DONT FORGET TO CHANGE THE IP RANGE
##DONT FORGET TO CHANGE THE IP RANGE
##DONT FORGET TO CHANGE THE IP RANGE
##DONT FORGET TO CHANGE THE IP RANGE
1..20 | % { $a = $_; write-host "------"; write-host "192.168.20.$a"; 22,53,80,445 | % {echo ((new-object Net.Sockets.TcpClient).Connect("192.168.20.$a",$_)) "Port $_ is open!"} 2>$null}